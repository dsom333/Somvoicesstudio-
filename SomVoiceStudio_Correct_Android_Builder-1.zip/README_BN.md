# Som Voice Studio — Android APK Builder

এটি একটি প্রাথমিক Android অ্যাপ প্রজেক্ট। GitHub Actions দিয়ে Debug APK তৈরি করার workflow আগে থেকেই যুক্ত আছে।

## কী আছে
- Android Text-to-Speech দিয়ে লেখা থেকে WAV অডিও তৈরি
- Android Speech Recognition service দিয়ে বাংলা কথা থেকে লেখা আনার চেষ্টা
- APK build করার GitHub Actions workflow

## সীমাবদ্ধতা
- এটি এখনো পূর্ণাঙ্গ Studio নয়।
- WAV তৈরি হয়; MP3 export নেই।
- Speech Recognition ফোনের speech service-এর ওপর নির্ভরশীল; অফলাইনে কাজ করবে এমন নিশ্চয়তা নেই।
- বাংলা TTS voice ফোনে ইনস্টল করা থাকতে হবে।
- JSON timestamp/word alignment এখনো নেই।
- Debug APK তৈরি হবে; Play Store release signing করা নয়।

## GitHub-এ আপলোড
ZIP extract করে ভেতরের সব ফাইল ও `.github` ফোল্ডারসহ repository root-এ upload করুন। ZIP ফাইলটি নিজে upload করবেন না।

## APK Build
GitHub repository → Actions → Build Som Voice Studio APK → Run workflow।
Build শেষ হলে workflow run-এর নিচে Artifacts থেকে `SomVoiceStudio-debug-apk` ডাউনলোড করুন।
