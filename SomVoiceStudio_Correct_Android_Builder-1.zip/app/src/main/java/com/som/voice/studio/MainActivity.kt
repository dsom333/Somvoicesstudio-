package com.som.voice.studio

import android.app.Activity
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.content.Intent
import android.speech.RecognizerIntent
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import java.io.File
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private lateinit var status: TextView
    private lateinit var input: EditText
    private lateinit var output: TextView
    private val speechRequest = 4102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(0xFFF7F7FB.toInt())
        }
        val title = TextView(this).apply {
            text = "Som Voice Studio"
            textSize = 26f
            setTextColor(0xFF202040.toInt())
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "বাংলা ভয়েস ইঞ্জিন প্রস্তুত হচ্ছে..."
            textSize = 14f
            setPadding(0, 12, 0, 12)
        }
        input = EditText(this).apply {
            hint = "এখানে বাংলা লেখা লিখুন..."
            minLines = 5
            gravity = Gravity.TOP
            textSize = 17f
            setPadding(12, 12, 12, 12)
        }
        val makeAudio = Button(this).apply {
            text = "লেখা থেকে অডিও তৈরি করুন (WAV)"
            setOnClickListener { makeWav() }
        }
        val listen = Button(this).apply {
            text = "কথা থেকে লেখা (Speech to Text)"
            setOnClickListener { startSpeechRecognition() }
        }
        output = TextView(this).apply {
            text = "ফলাফল এখানে দেখা যাবে"
            textSize = 15f
            setPadding(0, 16, 0, 8)
        }
        root.addView(title, matchWrap())
        root.addView(status, matchWrap())
        root.addView(input, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        root.addView(makeAudio, matchWrap())
        root.addView(listen, matchWrap())
        root.addView(output, matchWrap())
        setContentView(root)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = 8 }

    override fun onInit(result: Int) {
        if (result == TextToSpeech.SUCCESS) {
            val bengali = tts?.setLanguage(Locale("bn", "IN"))
            status.text = if (bengali == TextToSpeech.LANG_MISSING_DATA ||
                bengali == TextToSpeech.LANG_NOT_SUPPORTED) {
                "আপনার ফোনের TTS ইঞ্জিনে বাংলা ভয়েস নাও থাকতে পারে। Google Speech Services-এ Bengali voice data ইনস্টল করুন।"
            } else {
                "বাংলা TTS প্রস্তুত। ভয়েসের মান ফোনে ইনস্টল করা TTS engine-এর ওপর নির্ভরশীল।"
            }
        } else {
            status.text = "TTS চালু করা যায়নি। ফোনের Text-to-Speech সেটিংস পরীক্ষা করুন।"
        }
    }

    private fun makeWav() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) {
            Toast.makeText(this, "আগে কিছু বাংলা লেখা লিখুন", Toast.LENGTH_SHORT).show()
            return
        }
        val file = File(getExternalFilesDir(null), "SomVoice_${System.currentTimeMillis()}.wav")
        val params = Bundle()
        params.putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "som_voice")
        val result = tts?.synthesizeToFile(text, params, file, "som_voice")
        if (result == TextToSpeech.SUCCESS) {
            output.text = "অডিও ফাইল তৈরি হচ্ছে: ${file.absolutePath}\nতৈরি সম্পন্ন হলে ফাইলটি অ্যাপের Android/data ফোল্ডারে থাকবে।"
        } else {
            output.text = "অডিও তৈরি করা যায়নি। বাংলা ভয়েস ডেটা ইনস্টল আছে কি না দেখুন।"
        }
    }

    private fun startSpeechRecognition() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "বাংলায় কথা বলুন")
        }
        try {
            startActivityForResult(intent, speechRequest)
        } catch (_: Exception) {
            Toast.makeText(this, "এই ফোনে Speech Recognition service পাওয়া যায়নি", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Legacy activity result callback for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == speechRequest && resultCode == RESULT_OK) {
            val matches = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val recognized = matches?.firstOrNull().orEmpty()
            input.setText(recognized)
            output.text = if (recognized.isNotBlank()) "স্বীকৃত লেখা:\n$recognized" else "কোনো কথা শনাক্ত হয়নি।"
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
